import pandas as pd
import matplotlib.pyplot as plt
df=pd.read_csv('sales_locations.csv')
(df.groupby('State')['Sales'].sum()).plot(kind='bar');plt.tight_layout();plt.savefig('sales_by_state.png')
print(df.groupby('State')['Sales'].sum())